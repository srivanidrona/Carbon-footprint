import React from 'react';
import Leaderboard from '../components/Leaderboard';
import Reviews from '../components/Reviews';

const Community = () => {
  const communityPageStyle = {
    padding: '20px',
    color: '#fff',
  };

  const sectionStyle = {
    marginBottom: '30px',
    padding: '20px',
    backgroundColor: '#333',
    borderRadius: '8px',
  };

  const headingStyle = {
    fontSize: '1.5rem',
    color: '#fff',
    marginBottom: '15px',
  };

  const userCardStyle = {
    marginBottom: '15px',
    padding: '10px',
    backgroundColor: '#444',
    borderRadius: '8px',
    boxShadow: '0 4px 6px rgba(0, 0, 0, 0.2)',
  };

  const reviewCardStyle = {
    marginBottom: '15px',
    padding: '10px',
    backgroundColor: '#444',
    borderRadius: '8px',
    boxShadow: '0 4px 6px rgba(0, 0, 0, 0.2)',
  };

  const reviewFormStyle = {
    marginTop: '20px',
  };

  const textareaStyle = {
    width: '100%',
    height: '100px',
    padding: '10px',
    borderRadius: '5px',
    border: '1px solid #ddd',
    marginBottom: '10px',
  };

  const buttonStyle = {
    padding: '10px 20px',
    backgroundColor: '#28a745',
    color: 'white',
    fontSize: '1em',
    cursor: 'pointer',
    borderRadius: '5px',
    border: 'none',
  };

  const buttonHoverStyle = {
    backgroundColor: '#218838',
  };

  return (
    <div style={communityPageStyle}>
      <h1>Community</h1>

      {/* Leaderboard Section */}
      <section style={sectionStyle}>
        <h2 style={headingStyle}>Leaderboard</h2>
        <Leaderboard />
      </section>

      {/* Reviews Section */}
      <section style={sectionStyle}>
        <h2 style={headingStyle}>User Reviews</h2>
        <Reviews />
      </section>
    </div>
  );
};

export default Community;
